/////////////////////////////////////////////////////////////////////
//Basic vars
/////////////////////////////////////////////////////////////////////
//import { defaultRequest as axios } from "axios";
const EnumFacing = Java.type("net.minecraft.util.EnumFacing");
import Settings from "./config";
import axios from "axios";
import RenderLib from "../RenderLib/index.js";
const prefix = '&7[&bBarryBunsClient&7]&r '
const mc = Client.getMinecraft()
const RightClick = new KeyBind(mc.field_71474_y.field_74313_G);
const LeftClick = new KeyBind(mc.field_71474_y.field_74312_F);
const WalkRight = new KeyBind(mc.field_71474_y.field_74366_z);
const WalkLeft = new KeyBind(mc.field_71474_y.field_74370_x);
const WalkBackward = new KeyBind(mc.field_71474_y.field_74368_y);
const WalkForward = new KeyBind(mc.field_71474_y.field_74351_w);
const Shift = new KeyBind(mc.field_71474_y.field_74311_E);
const WalkJump = new KeyBind(mc.field_71474_y.field_74314_A);
/////////////////////////////////////////////////////////////////////
//scan
/////////////////////////////////////////////////////////////////////

register("renderWorld", () => {
        settingCurrentAotvCords = Settings.currentMacroSpot
        if(settingCurrentAotvCords === 0.0) {
            aotvBlocksX = [429,426,433,433,440,447,460,462,444,446,449,454,465,462,468,462,467,464,473,478,486,474,480,486,480,486,481,475,469,462,457,462,456,456,440,442]
            aotvBlocksY = [45,43,47,45,44,39,30,30,31,34,34,36,39,43,31,36,41,47,31,34,39,53,43,44,51,56,56,44,54,48,47,58,58,53,39,41]
            aotvBlocksZ = [589,584,585,588,583,583,575,581,600,604,624,622,618,622,625,629,631,632,644,643,644,644,633,628,627,623,616,617,622,608,610,605,596,608,611,600]
            for(let i = 0; i < aotvBlocksX.length; i++) {
                RenderLib.drawEspBox(aotvBlocksX[i] + 0.5, aotvBlocksY[i] + 1, aotvBlocksZ[i] + 0.5, 1, 1, 1, 5, 5, 1, true)
                Tessellator.drawString(i + 1, aotvBlocksX[i] + 0.5, aotvBlocksY[i] + 1.5, aotvBlocksZ[i] + 0.5);
            }
            //ChatLib.chat(aotvBlocksX.length)
            } else if(settingCurrentAotvCords === 1.0) {
            aotvBlocksX = [769,772,774,776,775,778,782,791,784,779,788,796,798,797,798,779,778,789,783,786,781,780,782]
            aotvBlocksY = [61,60,59,59,55,61,53,54,52,55,46,44,49,50,53,30,34,32,32,32,31,34,39]
            aotvBlocksZ = [672,666,661,655,651,651,656,660,664,664,667,675,682,688,693,669,666,668,664,657,655,649,649]
            for(let i = 0; i < aotvBlocksX.length; i++) {
                RenderLib.drawEspBox(aotvBlocksX[i] + 0.5, aotvBlocksY[i] + 1, aotvBlocksZ[i] + 0.5, 1, 1, 1, 5, 5, 1, true)
                Tessellator.drawString(i + 1, aotvBlocksX[i] + 0.5, aotvBlocksY[i] + 1.5, aotvBlocksZ[i] + 0.5);
            }
            } else if(settingCurrentAotvCords === 2.0) {
                aotvBlocksX = [466,466,463,460,463,470,472,488,476,476,490,492,485,478,478,487,488,502,494,503,500,506,503,492,492,485,488,480,475,474]
                aotvBlocksY = [63,65,64,69,76,79,82,69,69,65,68,78,83,68,64,69,77,91,82,64,65,68,75,66,78,83,64,69,69,75]
                aotvBlocksZ = [758,773,776,783,786,788,782,788,786,794,776,790,791,774,801,803,801,795,780,786,790,778,775,768,773,773,761,759,754,759]
                for(let i = 0; i < aotvBlocksX.length; i++) {
                    RenderLib.drawEspBox(aotvBlocksX[i] + 0.5, aotvBlocksY[i] + 1, aotvBlocksZ[i] + 0.5, 1, 1, 1, 5, 5, 1, true)
                    Tessellator.drawString(i + 1, aotvBlocksX[i] + 0.5, aotvBlocksY[i] + 1.5, aotvBlocksZ[i] + 0.5);
                }
            } else if (settingCurrentAotvCords === 3.0) {
                aotvBlocksX = [331,338,343,335,331,316,307,298,298,283,278,278,270,262,264,262,266,271,286,291,290,292,294,297,299,294,300,314,303,306,314,311,319,324,327,325]
                aotvBlocksY = [50,49,46,39,34,37,31,51,51,52,51,41,38,43,49,54,48,50,41,40,34,44,37,48,52,40,44,40,41,36,43,41,41,47,38,44]
                aotvBlocksZ = [741,711,726,724,725,730,729,733,740,750,755,766,769,755,756,757,742,742,741,733,721,721,709,703,691,690,679,700,706,703,714,721,714,713,706,702]
                    for(let i = 0; i < aotvBlocksX.length; i++) {
                        RenderLib.drawEspBox(aotvBlocksX[i] + 0.5, aotvBlocksY[i] + 1, aotvBlocksZ[i] + 0.5, 1, 1, 1, 5, 5, 1, true)
                        Tessellator.drawString(i + 1, aotvBlocksX[i] + 0.5, aotvBlocksY[i] + 1.5, aotvBlocksZ[i] + 0.5);
                    }
            } else if (settingCurrentAotvCords === 4.0) {
                ChatLib.chat(prefix + " " + aotvBlocksX.length + " Cords")
            } else if(settingCurrentAotvCords === 5.0) {
                //nothing
            }
})

register("command", () => Settings.openGUI()).setName("barrybuns");
register("command", () => Settings.openGUI()).setName("bbc");
register("command", () => Settings.openGUI()).setName("oringo");
register("command", () => Settings.openGUI()).setName("pizza");

register("WorldLoad", () => {
    if(everythingON === true) {
        if(ScoreBoard() === true) {
            if(Settings.autoDisconnect === 0) {
                onStop()
                Client.disconnect()
            } else {
            onStop()
            }
        }
    }   
    if(enabledOn_mithril === true) {
        if(ScoreBoard() === true) {
            if(Settings.autoDisconnect === 0) {
                onStop_mithril()
                Client.disconnect()
            } else {
            onStop_mithril()
            }
        }
    }
})

let bigBlockOnly = false
let Blocks = []
let clear = true
function scan() {
    if(clear === true) {
        clear = false
        Blocks = []
    }
    // ChatLib.chat(prefix + " Scanned area For gemStones")
    //startMiningStuck = 0
    //Player.setHeldItemIndex(4)
    //let blockPlayer = World.getBlockAt(Math.ceil(Player.getX()), Player.getY() -1 , Math.ceil(Player.getZ() -1 ))
    for (let x = 0; x < 12; x++) {
        for (let y = 0; y < 6; y++) {
            for (let z = 0; z < 12; z++) {
                let block = World.getBlockAt(Player.getX() + x - 6, Player.getY() + y - 2, Player.getZ() + z - 6)
                let dX = Player.getX() - block.getX()
                let dZ = Player.getZ() - block.getZ()
                let dY = (Player.getY() + 1.25) - block.getY()
                let dis = Math.sqrt((dX * dX) + (dZ * dZ))
                let dis2 = Math.sqrt((dis * dis) + (dY * dY))
                if(block.toString().includes("glass")) {
                if((block.getState().toString().includes("red") && settingCurrentAotvCords != 2.0) || (block.getState().toString().includes("orange") && settingCurrentAotvCords === 2.0) || mineEveryType === true) {
                    if(block.getX() + 0.5 === Player.getX() && block.getZ() + 0.5 === Player.getZ() && block.getY() < Player.getY()) {
                        //nothing
                    } else if(block.toString().includes("glass_pane")) {
                         if(dis2 < 3.8 && bigBlockOnly === 1) {
                            Blocks.push(block)
                        }
                    } else if(dis2 < 4.5){
                         Blocks.push(block)
                    }
                    }
                }
                }
            }
        }
        // for(let i = 0; i < Blocks.length; i++) {
        //     ChatLib.chat(Blocks[i])
        // }
        clear = true
    }

let toggleOn = true
register("Command", () => {
    if(toggleOn === true) {
        ChatLib.chat(prefix + "toggled only Blocks On")
        bigBlockOnly = true
        toggleOn = false
    } else if(toggleOn === false) {
        ChatLib.chat(prefix + "toggled only Blocks Off")
        bigBlockOnly = true
        toggleOn = true
    }
}).setName("BigBlocks")

register("Command", () => {
    scan()
}).setName("scan")  
/////////////////////////////////////////////////////////////////////
//LookAt
/////////////////////////////////////////////////////////////////////

let hoekYaw
let hoekPitch
function lookAt(x, y, z) {
    if(x === undefined || y === undefined || z === undefined) {
        ChatLib.chat(prefix + " put in cords nigga")
    } else {
    //ChatLib.chat(prefix + " look at block " + x + ", " + y + ", " + z)
    let PlayerAngleYaw = Player.getPlayer().field_70177_z
    let AngleYaw
    PlayerAngleYaw %= 360
    let dX = Player.getX() - x + 0.00001
    let dZ = Player.getZ() - z + 0.00001
    let dY = Player.getY() - y
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    if(dX < 0.0 && dZ < 0.0) {
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX)) + 180
    } else if(dZ < 0.0 && dX > 0.0) {
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX)) + 360
    } else if(dZ > 0.0 && dX < 0.0) {
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX)) + 180
    } else if(dZ > 0.0 && dX > 0.0){
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX))
    }
    hoekYaw = AngleYaw - PlayerAngleYaw + 90
    if(hoekYaw > 180) {
        hoekYaw -= 360
    } if(hoekYaw < -180) {
        hoekYaw += 360
    }
    vlookSmooth = 0
    //Player.getPlayer().field_70177_z += hoekYaw + 90
    hoekPitch = radians_to_degrees(Math.atan(dY/dis)) - Player.getPlayer().field_70125_A
    //Player.getPlayer().field_70125_A += hoekPitch
}
}

let hoekYaw2
function degreeRannge(x,y,z) {
    if(x === undefined || y === undefined || z === undefined) {
        ChatLib.chat(prefix + " put in cords nigga")
    } else {
    let PlayerAngleYaw = Player.getPlayer().field_70177_z
    let AngleYaw
    PlayerAngleYaw %= 360
    let dX = Player.getX() - x + 0.00001
    let dZ = Player.getZ() - z + 0.00001
    if(dX < 0.0 && dZ < 0.0) {
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX)) + 180
    } else if(dZ < 0.0 && dX > 0.0) {
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX)) + 360
    } else if(dZ > 0.0 && dX < 0.0) {
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX)) + 180
    } else if(dZ > 0.0 && dX > 0.0){
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX))
    }
    hoekYaw2 = AngleYaw - PlayerAngleYaw + 90   
    if(hoekYaw2 > 180) {
        hoekYaw2 -= 360
    } if(hoekYaw2 < -180) {
        hoekYaw2 += 360
    }
}
return Math.sqrt(hoekYaw2 * hoekYaw2)
}

let hoekPitch2
function rotaPitchRange(x,y,z) {
    let dX = Player.getX() - x + 0.00001
    let dZ = Player.getZ() - z + 0.00001
    let dY = Player.getY() - y
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    hoekPitch2 = radians_to_degrees(Math.atan(dY/dis)) - Player.getPlayer().field_70125_A
    return Math.sqrt(hoekPitch2 * hoekPitch2)
}

let vlookSmooth = 1000
let amountSmooth = 2

//field_73088_d
function radians_to_degrees(radians) {
    var pi = Math.PI;
    return radians * (180/pi);
  }

register("Command", (x,y,z) => {
    lookAt(x,y,z)
}).setName("lookAt")
/////////////////////////////////////////////////////////////////////
//scan and mine
/////////////////////////////////////////////////////////////////////

let mining = true
let allowedToNextSpot = true    
let countDownStuckAotv = 1000
let startStuck = true
let settingPlayerDetection = Settings.playerDetection
let settingPlayerSneak = Settings.currentSneak
let settingCurrentAotvCords


let closestBlock
let closestPos
let minedOnce = false
let Finishedlook = false
function mineTime() {
    if(aotving === false) {
        if(settingPlayerSneak === "On" || settingPlayerSneak === 0) {
            Shift.setState(true)
        }
    let firstLookForMine = true
    minedOnce = false
    closestBlock = undefined
    scan()
    for(let i = 0; i < Blocks.length; i++) {
        if(Blocks[i].toString().includes("air") === false) {
        if(firstLookForMine === true) {
            closestBlock = Blocks[i]
            firstLookForMine = false
            minedOnce = true
        } 
        let blocksLengthDegree = degreeRannge(Blocks[i].getX(), Blocks[i].getY(), Blocks[i].getZ())
        let closestBlockLengthDegree = degreeRannge(closestBlock.getX(), closestBlock.getY(), closestBlock.getZ())
        let blocksLengthRota = rotaPitchRange(Blocks[i].getX(), Blocks[i].getY(), Blocks[i].getZ())
        let closestBlockLengthRota = rotaPitchRange(closestBlock.getX(), closestBlock.getY(), closestBlock.getZ())
        if(firstLookForMine === false && (Math.sqrt(blocksLengthDegree*blocksLengthDegree + blocksLengthRota*blocksLengthRota) < Math.sqrt(closestBlockLengthDegree*closestBlockLengthDegree + closestBlockLengthRota*closestBlockLengthRota))/*(degreeRannge(Blocks[i].getX(), Blocks[i].getY(), Blocks[i].getZ()) < degreeRannge(closestBlock.getX(), closestBlock.getY(), closestBlock.getZ()) && rotaPitchRange(Blocks[i].getX(), Blocks[i].getY(), Blocks[i].getZ()) < rotaPitchRange(closestBlock.getX(), closestBlock.getY(), closestBlock.getZ()))*/) {
            minedOnce = true
            closestBlock = Blocks[i]
        }
    }
    } if(Blocks.length != 0){
        let ofSet = 1
        if(closestBlock.getY() === Player.getY() - 2) {
        if((World.getBlockAt(Player.getX() + 1, closestBlock.getY(), Player.getZ() + 1)) ||
           (World.getBlockAt(Player.getX() - 1, closestBlock.getY(), Player.getZ() + 1)) ||
           (World.getBlockAt(Player.getX() - 1, closestBlock.getY(), Player.getZ() - 1)) ||
           (World.getBlockAt(Player.getX() + 1, closestBlock.getY(), Player.getZ() - 1))) {
            //ChatLib.chat(prefix + " Detected Low")
            ofSet = 0.8
           }
        }
    if(settingNuker === 1) {
        lookAt(closestBlock.getX() + 0.5, closestBlock.getY() - ofSet, closestBlock.getZ() + 0.5)
        LeftClick.setState(true)
    } else {
        closestPos = new BP(closestBlock.getX(), closestBlock.getY(), closestBlock.getZ())
        Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotDrill))
        Client.sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, closestPos, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
        lookAt(closestBlock.getX() + 0.5, closestBlock.getY() - ofSet, closestBlock.getZ() + 0.5)
    }
    Player.setHeldItemIndex(hotBarSlotDrill)
    Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotDrill));
    firstLookForMine = true
    startMiningStuck = 0
    }
    scan()
    if(/*minedOnce === false*/ Blocks.length === 0.0) {
        ChatLib.chat(prefix + " All gemstones mined moving on to the next vein")
        failSaveJump = 0
            allowedToNextSpot = false
            if(settingNuker === 1) {
                LeftClick.setState(false)
                }
            on_Or_Off = false
            miningSpeedBoost = false
            aotvNext()
    }
    }
}
let startMiningStuck = 101
let waitLookingAway = 31
let oneDerection = "right"
let failSaveJump = 0
let settingsWait = 60
/////////////////////////////////////////////////////////////////////
//AutoSpeedBoost
/////////////////////////////////////////////////////////////////////
let gtheMsg
register("Chat", (theMsg) => {  
        gtheMsg = theMsg
        if(on_Or_Off === true) {
            if(gtheMsg === "Mining Speed Boost is now available!") {
                    useSpeedBoost()
            }
        }
}).setCriteria("${theMsg}")

const C08PacketPlayerBlockPlacement = Java.type("net.minecraft.network.play.client.C08PacketPlayerBlockPlacement");
const C0APacketAnimation = Java.type("net.minecraft.network.play.client.C0APacketAnimation")
const C09PacketHeldItemChange = Java.type("net.minecraft.network.play.client.C09PacketHeldItemChange");
const C07PacketPlayerDigging = Java.type("net.minecraft.network.play.client.C07PacketPlayerDigging")
const BP = Java.type("net.minecraft.util.BlockPos");
const BP2 = Java.type("BlockPos");
let firstSpeed = true
let miningSpeedBoost = false

function useSpeedBoost() {
    if(hotBarSlotBlueCheese != undefined) {
    firstSpeed = false
    ChatLib.chat(prefix + " Used Mining Speed Boost")
    Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotBlueCheese));
    Client.sendPacket(new C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(hotBarSlotBlueCheese).getItemStack(), 0, 0, 0))
    Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotDrill));
    }
}

let countDownWaiting = 2000



register("Command", () => {
    mineTime()
}).setName("minelol")

/////////////////////////////////////////////////////////////////////
let on_Or_Off = false
let toggleOnOrOff = true
let everythingON = false

function onStart() {
    settingPlayerDetection = Settings.playerDetection
    settingPlayerSneak = Settings.currentSneak
    bigBlockOnly = Settings.currentBigBlocks
    settingCurrentAotvCords_mithril = Settings.currentMacroSpot_mithirl
    settingNuker = Settings.currentNuke
    //Player.getPlayer().field_70177_z = 90
    //Player.getPlayer().field_70125_A = 0
    detectedPlayer = false
    failSaveJump = 0
    coolDownScan = 0
    countDownStuckAotv = 1000
    startStuck = true
    ChatLib.chat(prefix + " toggled On")
    everythingON = true
    miningSpeedBoost = true
    toggleOnOrOff = false
    on_Or_Off = true
    detectLagFirst = true
    //countDownRightClick = 0
    countDownSpeedBoost = 0
    countDownAotv = 100
    countDownStop = 100
    waitDelayNothing = 1000
    coolDownWaitAgainAotv = 1000
    LeftClick.setState(false)
    RightClick.setState(false)

}

function onStop() {
    countDownStuckAotv = 100
    firstSet = true
    coolDownScan = 1000
    Blocks = []
    clear = true
    bigBlockOnly = false
    vlookSmooth = 1000
    mining = true
    allowedToNextSpot = true
    minedOnce = false
    startMiningStuck = 10
    waitLookingAway = 31
    firstDetect = true
    aotving = false
    countDownAotv = 100
    countDownStop = 100
    waitDelayNothing = 100
    coolDownWaitAgainAotv = 100
    tryAgainAotv = 1000
    tryAgainFails = 0
    waitForScan = 1000
    countDownWaiting = 100
    startMiningStuck = 1000
    waitLookingAway = 1000
    countDownSpeedBoost = 10000
    countDownRightClick = 100
    miningSpeedBoost = false
    ChatLib.chat(prefix + " toggled Off")
    everythingON = false
    on_Or_Off = false
    toggleOnOrOff = true
    RightClick.setState(false)
    LeftClick.setState(false)
    Shift.setState(false)

}



register("Command", () => {
    if(toggleOnOrOff === true) {
        selectedAotvCords()
        onStart()
        findAotvAndDrill()
        findCurrentAotvSpot() 
    } else if(toggleOnOrOff === false) {
        onStop()
    }
}).setName("gemstone")
/////////////////////////////////////////////////////////////////////

function selectedAotvCords() {
    settingCurrentAotvCords = Settings.currentMacroSpot
    //ChatLib.chat(settingCurrentAotvCords)
    if(settingCurrentAotvCords === 0.0) {
    aotvBlocksX = [429,426,433,433,440,447,460,462,444,446,449,454,465,462,468,462,467,464,473,478,486,474,480,486,480,486,481,475,469,462,457,462,456,456,440,442]
    aotvBlocksY = [45,43,47,45,44,39,30,30,31,34,34,36,39,43,31,36,41,47,31,34,39,53,43,44,51,56,56,44,54,48,47,58,58,53,39,41]
    aotvBlocksZ = [589,584,585,588,583,583,575,581,600,604,624,622,618,622,625,629,631,632,644,643,644,644,633,628,627,623,616,617,622,608,610,605,596,608,611,600]
    //ChatLib.chat(aotvBlocksX.length)
    } else if(settingCurrentAotvCords === 1.0) {
    aotvBlocksX = [769,772,774,776,775,778,782,791,784,779,788,796,798,797,798,779,778,789,783,786,781,780,782]
    aotvBlocksY = [61,60,59,59,55,61,53,54,52,55,46,44,49,50,53,30,34,32,32,32,31,34,39]
    aotvBlocksZ = [672,666,661,655,651,651,656,660,664,664,667,675,682,688,693,669,666,668,664,657,655,649,649]
    } else if(settingCurrentAotvCords === 2.0) {
        aotvBlocksX = [466,466,463,460,463,470,472,488,476,476,490,492,485,478,478,487,488,502,494,503,500,506,503,492,492,485,488,480,475,474]
        aotvBlocksY = [63,65,64,69,76,79,82,69,69,65,68,78,83,68,64,69,77,91,82,64,65,68,75,66,78,83,64,69,69,75]
        aotvBlocksZ = [758,773,776,783,786,788,782,788,786,794,776,790,791,774,801,803,801,795,780,786,790,778,775,768,773,773,761,759,754,759]
    } else if (settingCurrentAotvCords === 3.0) {
        aotvBlocksX = [331,338,343,335,331,316,307,298,298,283,278,278,270,262,264,262,266,271,286,291,290,292,294,297,299,294,300,314,303,306,314,311,319,324,327,325]
        aotvBlocksY = [50,49,46,39,34,37,31,51,51,52,51,41,38,43,49,54,48,50,41,40,34,44,37,48,52,40,44,40,41,36,43,41,41,47,38,44]
        aotvBlocksZ = [741,711,726,724,725,730,729,733,740,750,755,766,769,755,756,757,742,742,741,733,721,721,709,703,691,690,679,700,706,703,714,721,714,713,706,702]
    } else if (settingCurrentAotvCords === 4.0) {
        ChatLib.chat(prefix + " " + aotvBlocksX.length + " Cords")
    }
}

let typeAotv = 0
let firstDetect = true
let aotving = false
let countDownAotv = 100
let countDownStop = 100
let waitDelayNothing = 1000
let coolDownWaitAgainAotv = 1000
let tryAgainAotv = 1000
let tryAgainFails = 0
let waitForScan = 100
let failSafeProve = false
let detectLagFirst = true
let aotvBlocksX //= [428.5,427.5,431.5,434.5,439.5,447.5,460.5,462.5,444.5,445.5,447.5,451.5,452.5,457.5,468.5,462.5,466.5,465.5,473.5,478.5,486.5,489.5,485.5,488.5,481.5,481.5,475.5,463.5,465.5,462.5,457.5,441.5,442.5]
let aotvBlocksY //= [45,43,46,45,44,39,32,30,31,34,33,34,37,37,32,36,42,47,31,34,39,46,44,56,55,43,44,42,40,47,46,37,41]
let aotvBlocksZ //= [589.5,585.5,585.5,587.5,583.5,583.5,576.5,581.5,600.5,604.5,622.5,623.5,620.5,621.5,625.5,629.5,631.5,632.5,644.5,642.5,643.5,627.5,628.5,626.5,616.5,630.5,617.5,621.5,617.5,608.5,610.5,610.5,600.5]
function aotvNext() {
    if(everythingON === true) {
        coolDownScan = 0
        startMiningStuck = 101
        aotving = true
        scan()
    //ChatLib.chat(prefix +  " Player Cords: " + Player.getX() + ', ' +(Player.getY() -2)+  ', ' +Player.getZ())
    //ChatLib.chat(prefix + " AotvCords: " + aotvBlocksX[typeAotv] + ', ' +aotvBlocksY[typeAotv]+  ', ' +aotvBlocksZ[typeAotv])
    //if(Player.getX() === aotvBlocksX[typeAotv] && Player.getY() - 2 === aotvBlocksY[typeAotv] && Player.getZ() === aotvBlocksZ[typeAotv] && Blocks.length === 0) {
        failSafeProve = true
        tryAgainFails = 0
    if(aotvBlocksX[0] === undefined || aotvBlocksY[0] === undefined || aotvBlocksZ[0] === undefined) {
        ChatLib.chat(prefix + " Can't aotv because there are no spots idiot!")
    }   typeAotv += 1
        nextX = aotvBlocksX[typeAotv]
        nextY = aotvBlocksY[typeAotv]
        nextZ = aotvBlocksZ[typeAotv]
    if(nextX === undefined) {
        ChatLib.chat(prefix + " ReAotving")
        typeAotv = 0
        Player.setHeldItemIndex(hotBarSlotAotv)
        Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotAotv));
        aotving = true
        if(settingNuker === 1) {
        LeftClick.setState(false)
        }
        Shift.setState(true)
        lookAt(aotvBlocksX[typeAotv] + 0.5, aotvBlocksY[typeAotv], aotvBlocksZ[typeAotv] + 0.5)
    } else {
        ChatLib.chat(prefix + " Aotving")
        startMiningStuck = 1000
        detectLagFirst = true
        Player.setHeldItemIndex(hotBarSlotAotv)
        Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotAotv));
        aotving = true
        if(settingNuker === 1) {
        LeftClick.setState(false)
        }
        Shift.setState(true)
        lookAt(nextX + 0.5, nextY, nextZ + 0.5  )
    //}
}
}
if(tryAgainFails === 5) {
    on_Or_Off = false
    everythingON = false
    toggleOnOrOff = true
    RightClick.setState(false)
    if(settingNuker === 1) {
        LeftClick.setState(false)
        }
    Shift.setState(false)
    ChatLib.chat(prefix + " tried 6 times and failed bad internet or can't reach next aotv block")
}
}

function goToNextCord() {
    Shift.setState(true)
    RightClick.setState(false)
    if(settingNuker === 1) {
        LeftClick.setState(false)
        }
    countDownAotv = 0
}

function distanceToPlayerLookingFaceBlock(x,y,z,faced) {
    let block = Player.lookingAt()
    //ChatLib.chat(block.getY())
    if(block.toString().includes(":stained_glass,")) {
    if(faced === "up") {
        let dX = block.getX() - x
        let dZ = block.getZ() - z
        let dY = block.getY() + 0.5 - y
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        //ChatLib.chat(dis2)
        return dis2
    } else if(faced === "down") {  
        let dX = block.getX() - x
        let dZ = block.getZ() - z
        let dY = block.getY() - 0.5 - y
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        //ChatLib.chat(dis2)
        return dis2 
    } else if(faced === "west") {  
        let dX = block.getX() + 1 - x
        let dZ = block.getZ() + 0.5 - z
        let dY = block.getY() - y
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        //ChatLib.chat(dis2)
        return dis2 
    } else if(faced === "east") {  
        let dX = block.getX() - x
        let dZ = block.getZ() + 0.5 - z
        let dY = block.getY() - y
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        //ChatLib.chat(dis2)
        return dis2  
    } else if(faced === "north") {   
        let dX = block.getX() + 0.5 - x
        let dZ = block.getZ() - z
        let dY = block.getY() - y
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        //ChatLib.chat(dis2)
        return dis2
    } else if(faced === "south") {   
        let dX = block.getX() + 0.5 - x
        let dZ = block.getZ() + 1 - z
        let dY = block.getY() - y
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        //ChatLib.chat(dis2)
        return dis2
    }
}
}

register("SpawnParticle", (x) => {
    if(everythingON === true && on_Or_Off === true && aotving === false && Settings.currentPresisionMiner === 0) {
        if(Player.lookingAt().toString().includes("glass")) {
        if(x.toString().includes("EntityCrit2FX") && distanceToPlayer(x.getX(), x.getY(), x.getZ()) < 7 && closestBlock != undefined) {
            let dX = closestBlock.getX() - x.getX()
            let dZ = closestBlock.getZ()- x.getZ()
            let dY = closestBlock.getY() - x.getY()
            let dis = Math.sqrt((dX * dX) + (dZ * dZ))
            let dis2 = Math.sqrt((dis * dis) + (dY * dY))
            if(dis2 < 1.6) {
                lookAt(x.getX(), x.getY() - 1.6, x.getZ())
            }
        }
    }
    }
})

let countDownSpeedBoost = 10000
let countDownRightClick = 100
let detectedPlayer = false
let settingNuker
register("Tick", () => {
    //ChatLib.chat(Player.lookingAt().getState())
    if(everythingON === true) {
        if(countDownStuckAotv < 200) {
            countDownStuckAotv += 1
        } else if(countDownStuckAotv === 200) {
            ChatLib.chat(prefix + " Stopped script because of very very very bad internet or couldnot reach the next spot setup your lobby better next time stupid")
            onStop()
            countDownStuckAotv += 1
        }
    if(countDownAotv < 3) {
        if(settingNuker === 1) {
            LeftClick.setState(false)
            }
        RightClick.setState(false)
        countDownAotv += 1
    } else if(countDownAotv === 3) {
        Shift.setState(true)
        RightClick.setState(true)
        countDownStop = 0
        countDownAotv += 1
    }
    if(countDownStop < 3) {
        LeftClick.setState(false)
        countDownStop += 1
    } else if(countDownStop === 3) {
        if(settingNuker === 1) {
            LeftClick.setState(false)
            }
        RightClick.setState(false)
        waitDelayNothing = 0
        countDownStop += 1
    }
    if(waitDelayNothing < 6) {
        waitDelayNothing += 1
        RightClick.setState(false)
    } else if(waitDelayNothing === 6) {
        if(settingNuker === 1) {
        LeftClick.setState(true)
        }
        Shift.setState(false)
        on_Or_Off = true
        allowedToNextSpot = true
        mining = true
        allowedToNextSpot = undefined
        aotving = false
        miningSpeedBoost = true
        waitDelayNothing += 1
    }

    if(countDownRightClick < 3) {
        WalkJump.setState(true)
        countDownRightClick += 1
    } else if(countDownRightClick === 3) {
        WalkJump.setState(false)
        countDownRightClick += 1
    }

    if(settingPlayerDetection === 0) {
    let nPs = World.getAllPlayers()
    for(let s = 0; s < nPs.length; s++) {
    if((distanceToPlayer(nPs[s].getX(),nPs[s].getY(),nPs[s].getZ()) < 5) && (distanceToPlayerFlat(nPs[s].getX(),nPs[s].getY(),nPs[s].getZ()) > 2) && (nPs[s].toString().includes(Player.getName()) === false) && (detectedPlayer === false)) {
        detectedPlayer = true
            ChatLib.chat(prefix + " Detected Player near you! Warping Out")
            onStop()
            ChatLib.say("/is")
    }
}
}
    }
    if(everythingON === true && aotving === false && noItems === false) {
        if(coolDownScan < 7) {
            coolDownScan += 1
        }
        if((coolDownScan === 7) && (Player.lookingAt().toString().includes(":cobblestone,") === false)) {
        let allEntity = World.getAllEntities()
        let foundMob = false
        for(let i = 0; i < allEntity.length; i++) {
            if(allEntity[i].toString().includes("Magma")) {
                if(distanceToPlayer(allEntity[i].getX(), allEntity[i].getY(), allEntity[i].getZ()) < 4 && aotving === false && distanceToPlayerFlat(allEntity[i].getX(), allEntity[i].getZ()) > 1.4) {
                    for(let j = 0; j < allEntity.length; j++) {
                        if(allEntity[j].toString().includes("/") && distanceToPlayer(allEntity[j].getX(), allEntity[j].getY(), allEntity[j].getZ()) < 5) {
                            on_Or_Off = false
                            foundMob = true
                            startMiningAgain = true
                            startMiningStuck = 0
                            lookAt(allEntity[i].getX(), allEntity[i].getY(), allEntity[i].getZ())
                            if(settingNuker === 1) {
                                LeftClick.setState(false)
                                }
                            Player.setHeldItemIndex(hotBarSlotFrozenScythe)
                            Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotFrozenScythe));
                            Client.sendPacket(new C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(hotBarSlotFrozenScythe).getItemStack(), 0, 0, 0))
                        }
                    }
                }
            }
            }
        if(foundMob === false && aotving === false) {
            Player.setHeldItemIndex(hotBarSlotDrill)
            on_Or_Off = true
        }
        if(startMiningAgain === true && foundMob === false) {
            Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotDrill));
            startMiningAgain = false
            onStop()
            onStart()
        }
        coolDownScan = 0
    }
    }
    if(countDownWaiting < 20) {
        countDownWaiting += 1
        } else if(countDownWaiting === 20) {
            countDownRightClick = 0
            countDownWaiting += 1
        }
        if(on_Or_Off === true) {
            if(gtheMsg === "Mining Speed Boost is now available!") {
                if(firstSpeed === true) {
                    useSpeedBoost()
                }
            } else if(gtheMsg === "You used your Mining Speed Boost Pickaxe Ability!") {
                firstSpeed = true
            }
        }
        if(startMiningStuck < settingsWait) {
            startMiningStuck += 1
        } else if(startMiningStuck == settingsWait) {
            failSaveJump += 1
            if(failSaveJump === 6) {
                countDownRightClick = 0
                failSaveJump = 0
            }
            on_Or_Off === false
            if(settingNuker === 1) {
                LeftClick.setState(false)
                }
            startMiningStuck += 1
            waitLookingAway = 0
            Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotFrozenScythe))
            Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotDrill));
            ChatLib.chat(prefix + " Stuck while Mining")
        }
        if(waitLookingAway < 15) {
            if(oneDerection === "right") {
                x3 = 6
                y3 = 0.6
            } else if(oneDerection === "left") {
                x3 = -6
                y3 = -0.6
            }
            Player.getPlayer().field_70177_z += x3
            Player.getPlayer().field_70125_A += y3
            if(settingNuker === 1) {
                LeftClick.setState(false)
                }
            waitLookingAway += 1
        } else if(waitLookingAway === 15) {
            if(oneDerection === "right") {
                oneDerection = "left"
            } else if(oneDerection === "left") {
                oneDerection = "right"
            }
            mineTime()
            on_Or_Off = true
            waitLookingAway += 1
            startMiningStuck = 0

        }
        if(everythingON === true) {
            if(Settings.smoothLook > -1) {
                amountSmooth = Settings.smoothLook + 1
            }
            if(Settings.stuckTimer > 0) {
                settingsWait = Settings.stuckTimer
            }
            if(vlookSmooth < amountSmooth && hoekPitch != undefined && hoekYaw != undefined) {
                Player.getPlayer().field_70177_z += hoekYaw/amountSmooth
                Player.getPlayer().field_70125_A += hoekPitch/amountSmooth
                vlookSmooth += 1
            }
            else if(vlookSmooth === amountSmooth && aotving === true) {
                goToNextCord()
                ChatLib.chat("here")
                vlookSmooth += 1
            }
            if(everythingON === true && noItems === false) {
            if(on_Or_Off === true) {
                let blockPos
                if(closestBlock != undefined) {
                blockPos = new BlockPos(closestBlock.getX(), closestBlock.getY(), closestBlock.getZ())
                }
                let plX = Player.getX()
                let plZ = Player.getZ()
                let X1 = Math.floor(plX)
                let Z1 = Math.floor(plZ)
                scan()
                if(X1 === aotvBlocksX[typeAotv] && Player.getY() - 2 === aotvBlocksY[typeAotv] && Z1 === aotvBlocksZ[typeAotv]) {
                    startStuck = true
                    countDownStuckAotv = 1000
                if(mining === true) {
                    mineTime()
                    mining = false
                    miningSpeedBoost = true
                } else if(closestBlock != undefined) {
                   if(Blocks.length === 0 && allowedToNextSpot === true) {
                        allowedToNextSpot = false
                        //ChatLib.chat("Stop")
                        if(settingNuker === 1) {
                        LeftClick.setState(false)
                        }
                        on_Or_Off = false
                        miningSpeedBoost = false
                        aotvNext()
                    } else if(mining === false && World.getBlockStateAt(blockPos).toString().includes("air")) {
                        if(settingNuker === 0) {
                        Client.sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, closestPos, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                        }
                    mining = true
                    }
                }
            } else if((X1 === aotvBlocksX[typeAotv] && Player.getY() - 2 === aotvBlocksY[typeAotv] && Z1 === aotvBlocksZ[typeAotv]) === false && startStuck === true) {
                startStuck = false
                countDownStuckAotv = 0
            }
        
        }
            }
        }
})

let firstSet = true
let mineEveryType = false
register("Command", () => {
    let plX = Player.getX()
    let plZ = Player.getZ()
    let X1 = Math.floor(plX)
    let Z1 =  Math.floor(plZ)
    if(firstSet === true) {
        firstSet = false
        mineEveryType = true
        ChatLib.chat(prefix + " Cleared AotvCords")
        aotvBlocksX = []
        aotvBlocksY = []
        aotvBlocksZ = []
    }
    aotvBlocksX.push(X1)
    aotvBlocksY.push(Player.getY() - 2)
    aotvBlocksZ.push(Z1)
    ChatLib.chat(prefix + " Added the cords " + X1 + " " + (Player.getY() -1) + " " + Z1)
}).setName("setcord")

register("Command", () => {
    typeAotv += 1
    ChatLib.chat(prefix + " Next Aotv")
}).setName("nextAotv")

register("Command", () => {
    aotvNext()
}).setName("aotvpath")

register("Command", () => {
    ChatLib.chat(prefix + " Cleared AotvCords")
    aotvBlocksX = []
    aotvBlocksY = []
    aotvBlocksZ = []
}).setName("clear")

ChatLib.chat("Barrybuns on top ")
register("Command", () => {
    console.log(aotvBlocksX.toString())
    console.log(aotvBlocksY.toString())
    console.log(aotvBlocksZ.toString())
    ChatLib.chat(aotvBlocksX.toString())
    ChatLib.chat(aotvBlocksY.toString())
    ChatLib.chat(aotvBlocksZ.toString())

}).setName("logcords")

register("Command", () => {
    findAotvAndDrill()
}).setName("find")

let hotBarSlotDrill
let hotBarSlotAotv
let hotBarSlotFrozenScythe
let hotBarSlotBlueCheese
let blueCheeseLine = "balls"
let noItems = true
function findAotvAndDrill() {
    let rangedWeapons = ["Frozen Scythe", "Juju Shortbow", "Terminator", "Spirit Sceptre", "Spirit Bow","Aurora Staff"]
    hotBarSlotBlueCheese = undefined
    hotBarSlotDrill = undefined
    hotBarSlotAotv = undefined
    hotBarSlotFrozenScythe = undefined
    for(let i = 0; i < 8; i++) {
        if(Player.getInventory().getStackInSlot(i) != null) {
        let itemPos = Player.getInventory().getStackInSlot(i).getName()
        let itemLore = Player.getInventory().getStackInSlot(i).getLore()
        for(let j = 0; j < itemLore.length; j++) {
            if(itemLore[j].toString().includes("Blue Cheese Goblin Omelette Part")) {
                blueCheeseLine = itemLore[j]
                break
            }
        }
        if(blueCheeseLine.toString().includes("Blue Cheese Goblin Omelette Part")) {
            blueCheeseLine = "not Drill"
            hotBarSlotBlueCheese = i
            ChatLib.chat(prefix + " Players Blue Cheese is in Slot " + (i + 1))
        }
        else if(itemPos.toString().includes("Aspect of the Void")){
            hotBarSlotAotv = i
            ChatLib.chat(prefix + " Players Aspect of the Void is in Slot " + (i + 1))
        }
        else if(itemPos.toString().includes("Drill")) {
            hotBarSlotDrill = i
            ChatLib.chat(prefix + " Players Drill is in Slot " + (i + 1))
        }
        else if (itemPos.toString().includes("Gemstone Gauntlet")) {
            hotBarSlotDrill = i
            ChatLib.chat(prefix + " Players Gauntlet is in Slot " + (i + 1))
        }
        else if (itemPos.toString().includes("Pickonimbus 2000")) {
            hotBarSlotDrill = i
            ChatLib.chat(prefix + " Players Pickonimbus is in Slot " + (i + 1))
        }
        for(let h = 0; h < rangedWeapons.length; h++) {
            if(itemPos.toString().includes(rangedWeapons[h])) {
                hotBarSlotFrozenScythe = i
                ChatLib.chat(prefix + " Detected players " + rangedWeapons[h] + " in Slot " + (i + 1))
                break
            }
        }
 
    }
}
    if(hotBarSlotBlueCheese === undefined) {
        hotBarSlotBlueCheese = hotBarSlotDrill
    }
    if(hotBarSlotAotv === undefined || hotBarSlotFrozenScythe === undefined || hotBarSlotDrill === undefined || hotBarSlotBlueCheese === undefined) {
        ChatLib.chat(prefix + " Not the required Items in the Hotbar Get yo money up not yo funny up")
        onStop()
        noItems = true
    } else {
        noItems = false
        useSpeedBoost()
    }
}

let startMiningAgain = false
let coolDownScan = 1000

function distanceToPlayer(x,y,z) {
    let dX = Player.getX() - x
    let dZ = Player.getZ() - z
    let dY = Player.getY() - y
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    let dis2 = Math.sqrt((dis * dis) + (dY * dY))
    return dis2
}

function distanceToPlayerHead(x,y,z) {
    let dX = Player.getX() - x
    let dZ = Player.getZ() - z
    let dY = (Player.getY() + 1.25) - y
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    let dis2 = Math.sqrt((dis * dis) + (dY * dY))
    return dis2
}
// function distanceToClosestBlock(x,y,z) {
//     let dX = closestBlock.getX() - x + 0.5
//     let dZ = closestBlock.getZ() - z + 0.5
//     let dY = closestBlock.getY() - y
//     let dis = Math.sqrt((dX * dX) + (dZ * dZ))
//     let dis2 = Math.sqrt((dis * dis) + (dY * dY))
//     return dis2
// }

        
let foundAotvSpot = false
function findCurrentAotvSpot() {
    let plX = Player.getX()
    let plZ = Player.getZ()
    let X1 = Math.floor(plX)
    let Z1 = Math.floor(plZ)
    for(let i = 0; i < aotvBlocksX.length; i++) {
        if((X1 === aotvBlocksX[i] && (Player.getY() - 2) === aotvBlocksY[i] && Z1 === aotvBlocksZ[i]) === true) {
            typeAotv = i
            foundAotvSpot = true
            ChatLib.chat(prefix + " Detected Player at " + (typeAotv + 1))
            break
        }
    }
    if(foundAotvSpot === false) {
        ChatLib.chat(prefix + " Not on Path")
        onStop()
    }
}
function distanceToPlayerFlat(x, z) {
    let dX = Player.getX() - x
    let dZ = Player.getZ() - z
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    return dis
}
// register("SpawnParticle", (x) => {
//     if(everythingON === true && closestBlock != undefined) {
//         if(x.toString().includes("EntityCrit2FX")) {
//     if(distanceToClosestBlock(x.getX() ,x.getY(),x.getZ()) < 1.1) {
//         //ChatLib.chat(x)
//         if(x.getY() > Player.getY() - 1 && closestBlock.toString().includes(":stained_glass,")) {
//         lookAt(x.getX() ,x.getY() - 1.6 ,x.getZ())
//         }
//     }
// }
// }
// })

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
let aotvBlocksX_mithril = [359.5,363.5,368.5,370.5,388.5,387.5,387.5,391.5,396.5,396.5,388.5,391.5,375.5,390.5,384.5,376.5,386.5,383.5,368.5,334.5,339.5,354.5,364.5]
let aotvBlocksY_mithril = [134,129,130,136,120,120,115,115,114,119,129,140,131,141,148,133,143,149,156,154,152,148,156]
let aotvBlocksZ_mithril = [532.5,529.5,538.5,526.5,527.5,521.5,503.5,500.5,504.5,522.5,514.5,513.5,498.5,506.5,497.5,491.5,481.5,490.5,501.5,506.5,523.5,514.5,545.5]
let enabledOn_mithril = false
let toggleOnOff_mithril = true

function findCurrentMacroSpot() {
    if(currentMacroSpot_mithirl === 0) {
    aotvBlocksX_mithril = [359.5,363.5,368.5,370.5,388.5,387.5,387.5,391.5,396.5,396.5,388.5,391.5,375.5,390.5,384.5,376.5,386.5,383.5,368.5,334.5,339.5,354.5,364.5]
    aotvBlocksY_mithril = [134,129,130,136,120,120,115,115,114,119,129,140,131,141,148,133,143,149,156,154,152,148,156]
    aotvBlocksZ_mithril = [532.5,529.5,538.5,526.5,527.5,521.5,503.5,500.5,504.5,522.5,514.5,513.5,498.5,506.5,497.5,491.5,481.5,490.5,501.5,506.5,523.5,514.5,545.5]
    }
}

function onStop_mithril() {
    ChatLib.chat(prefix + " Disabled Mithril Macro")
    startMiningStuck_mithril = 1000
    waitLookingAway_mithril = 1000
    mining_mithril = false
    enabledOn_mithril = false
    toggleOnOff_mithril = true
}

function onStart_mithril() {
    ChatLib.chat(prefix + " Enabled Mithril Macro")
    settingPlayerDetection = Settings.playerDetection
    settingPlayerSneak = Settings.currentSneak
    bigBlockOnly = Settings.currentBigBlocks
    settingCurrentAotvCords_mithril = Settings.currentMacroSpot_mithirl
    settingNuker = Settings.currentNuke
    failSaveJump_mithril = 0
    mining_mithril = true
    enabledOn_mithril = true
    toggleOnOff_mithril = false
}

let Blocks_mithril = []
let clear_mithril = true
function scan_mithril() {
    if(clear_mithril === true) {
        clear_mithril = false
        Blocks_mithril = []
    }
    //ChatLib.chat(prefix + " Scanned area For prismarine")
    for (let x = 0; x < 12; x++) {
        for (let y = 0; y < 7; y++) {
            for (let z = 0; z < 12; z++) {
                let block = World.getBlockAt(Player.getX() + x - 6, Player.getY() + y - 2, Player.getZ() + z - 6)
                let dX = Player.getX() - block.getX()
                let dZ = Player.getZ() - block.getZ()
                let dY = (Player.getY() + 1.25) - block.getY()
                let dis = Math.sqrt((dX * dX) + (dZ * dZ))
                let dis2 = Math.sqrt((dis * dis) + (dY * dY))
                if(block.toString().includes("pris") || block.toString().includes("wool")) {
                    if(block.getX() + 0.5 === Player.getX() && block.getZ() + 0.5 === Player.getZ() && block.getY() < Player.getY()) {
                        //nothing
                    } else if(dis2 < 4.5){
                         Blocks_mithril.push(block)
                    }
                    }
                }
            }
        }
        // for(let i = 0; i < Blocks.length; i++) {
        //     ChatLib.chat(Blocks[i])
        // }
        clear_mithril = true
    }

let hoekYaw_mithril
let hoekPitch_mithril
let vlookSmooth_mithril = 1000
function lookAt_mithril(x, y, z) {
    if(x === undefined || y === undefined || z === undefined) {
        ChatLib.chat(prefix + " put in cords nigga")
    } else {
    //ChatLib.chat(prefix + " look at block " + x + ", " + y + ", " + z)
    let PlayerAngleYaw = Player.getPlayer().field_70177_z
    let AngleYaw
    PlayerAngleYaw %= 360
    let dX = Player.getX() - x + 0.00001
    let dZ = Player.getZ() - z + 0.00001
    let dY = Player.getY() - y
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    if(dX < 0.0 && dZ < 0.0) {
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX)) + 180
    } else if(dZ < 0.0 && dX > 0.0) {
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX)) + 360
    } else if(dZ > 0.0 && dX < 0.0) {
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX)) + 180
    } else if(dZ > 0.0 && dX > 0.0){
        AngleYaw = radians_to_degrees(Math.atan(dZ/dX))
    }
    hoekYaw_mithril = AngleYaw - PlayerAngleYaw + 90
    if(hoekYaw_mithril > 180) {
        hoekYaw_mithril -= 360
    } if(hoekYaw_mithril < -180) {
        hoekYaw_mithril += 360
    }
    vlookSmooth_mithril = 0
    //Player.getPlayer().field_70177_z += hoekYaw + 90
    hoekPitch_mithril = radians_to_degrees(Math.atan(dY/dis)) - Player.getPlayer().field_70125_A
    //Player.getPlayer().field_70125_A += hoekPitch
}
}

let mining_mithril = false
let closestBlock_mithril
let minedOnce_mithril = false
function lookAtPrisMarine() {
    if(aotving_mithril === false) {
        let firstLookForMine = true
        minedOnce_mithril = false
        closestBlock_mithril = undefined
        scan_mithril()
        for(let i = 0; i < Blocks_mithril.length; i++) {
            if(Blocks_mithril[i].toString().includes("air") === false) {
            if(firstLookForMine === true) {
                closestBlock_mithril = Blocks_mithril[i]
                firstLookForMine = false
                minedOnce_mithril = true
            } 
            let blocksLengthDegree = degreeRannge(Blocks_mithril[i].getX(), Blocks_mithril[i].getY(), Blocks_mithril[i].getZ())
            let closestBlockLengthDegree = degreeRannge(closestBlock_mithril.getX(), closestBlock_mithril.getY(), closestBlock_mithril.getZ())
            let blocksLengthRota = rotaPitchRange(Blocks_mithril[i].getX(), Blocks_mithril[i].getY(), Blocks_mithril[i].getZ())
            let closestBlockLengthRota = rotaPitchRange(closestBlock_mithril.getX(), closestBlock_mithril.getY(), closestBlock_mithril.getZ())
            if(firstLookForMine === false && (Math.sqrt(blocksLengthDegree*blocksLengthDegree + blocksLengthRota*blocksLengthRota) < Math.sqrt(closestBlockLengthDegree*closestBlockLengthDegree + closestBlockLengthRota*closestBlockLengthRota))) {
                minedOnce_mithril = true
                closestBlock_mithril = Blocks_mithril[i]
            }
        }
        } 
        if(Blocks_mithril.length != 0){
            let ofSet = 1
            if(closestBlock_mithril.getY() < Player.getY()) {
            if((World.getBlockAt(Player.getX() + 1, closestBlock_mithril.getY(), Player.getZ() + 1)) ||
               (World.getBlockAt(Player.getX() - 1, closestBlock_mithril.getY(), Player.getZ() + 1)) ||
               (World.getBlockAt(Player.getX() - 1, closestBlock_mithril.getY(), Player.getZ() - 1)) ||
               (World.getBlockAt(Player.getX() + 1, closestBlock_mithril.getY(), Player.getZ() - 1))) {
                ofSet = 0.8
               }
            }
        lookAt_mithril(closestBlock_mithril.getX() + 0.5, closestBlock_mithril.getY() - ofSet, closestBlock_mithril.getZ() + 0.5)
        LeftClick.setState(true)
        Player.setHeldItemIndex(hotBarSlotDrill)
        Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotDrill));
        firstLookForMine = true
        startMiningStuck_mithril = 0
        }
        if(minedOnce_mithril === false) {
            ChatLib.chat(prefix + " Nothing Left to Mine going to Next Cord")
            aotvNext_mithril()
        }
        }
}

function findCurrentAotvSpot_mithril() {
    let foundAotvSpot = false
    let plX = Player.getX()
    let plZ = Player.getZ()
    let X1 = (plX - (Player.getX() % 1)) + 0.5
    let Z1 = (plZ - (Player.getZ() % 1)) + 0.5
    for(let i = 0; i < aotvBlocksX.length; i++) {
        if((X1 === aotvBlocksX_mithril[i] && (Player.getY() - 2) === aotvBlocksY_mithril[i] && Z1 === aotvBlocksZ_mithril[i]) === true) {
            typeAotv_mithril = i
            foundAotvSpot = true
            ChatLib.chat(prefix + " Detected Player at " + (typeAotv_mithril + 1))
            break
        }
    }
    if(foundAotvSpot === false) {
        ChatLib.chat(prefix + " Not on Path")
        onStop_mithril()
    }
    return typeAotv_mithril
}

let aotving_mithril = false
let typeAotv_mithril
function aotvNext_mithril() {
    aotving_mithril = true
    findCurrentAotvSpot_mithril()
    if(typeAotv_mithril === aotvBlocksX_mithril.length -1) {
        typeAotv_mithril = -1
    }
    lookAt_mithril(aotvBlocksX_mithril[typeAotv_mithril + 1], aotvBlocksY_mithril[typeAotv_mithril + 1], aotvBlocksZ_mithril[typeAotv_mithril + 1])
}

register("Command", () => {
    if(toggleOnOff_mithril === true) {
        findCurrentAotvSpot_mithril()
        findAotvAndDrill()
        onStart_mithril()
    } else if(toggleOnOff_mithril === false) {
        onStop_mithril()
    }
}).setName("mithril")

register("Command", () => {
    scan_mithril()
}).setName("scan1")

// register("Command", (x) => {
//     if(x > 0){
//         ChatLib.chat(prefix + " Set smoothLook to " + x + " Ticks")
//         amountSmooth = x
//         amountSmooth_mithril = x
//     } else {
//         ChatLib.chat(prefix + " put in /smoothlook (Amount of gameTicks)")
//     }
// }).setName("smoothlook")

let startMiningStuck_mithril = 1000
let waitLookingAway_mithril = 1000
let oneDerection_mithril = "right"
let amountSmooth_mithril = 2
let coolDownInOut_enterExit = 0
let coolDownInOut_Confirm = 0   
let coolDownWaitTime = 1000
register("Tick", () => {
    if(enabledOn_mithril === true) {
        if(vlookSmooth_mithril < amountSmooth_mithril) {
            Player.getPlayer().field_70177_z += hoekYaw_mithril/amountSmooth_mithril
            Player.getPlayer().field_70125_A += hoekPitch_mithril/amountSmooth_mithril
            vlookSmooth_mithril += 1
        } else if(vlookSmooth_mithril === amountSmooth_mithril && aotving_mithril === true) {
            vlookSmooth_mithril += 1
            Shift.setState(true)
            Player.setHeldItemIndex(hotBarSlotAotv)
            Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotAotv))
        } else if(vlookSmooth_mithril < amountSmooth_mithril + 2 && aotving_mithril === true) {
            vlookSmooth_mithril += 1
            Client.sendPacket(new C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(hotBarSlotAotv).getItemStack(), 0, 0, 0))
        } else if(vlookSmooth_mithril < amountSmooth_mithril + 12 && aotving_mithril === true) {
            vlookSmooth_mithril += 1
            Shift.setState(false)
        } else if(vlookSmooth_mithril < amountSmooth_mithril + 27 && aotving_mithril === true) {
            vlookSmooth_mithril += 1
            aotving_mithril = false
            onStart_mithril()
        }

        if(startMiningStuck_mithril < settingsWait) {
            startMiningStuck_mithril += 1
        } else if(startMiningStuck_mithril === settingsWait) {
                startMiningStuck_mithril = 0
                waitLookingAway_mithril = 0
        }
        
        if(waitLookingAway_mithril < 15) {
            if(oneDerection_mithril === "right") {
                x3 = 6
                y3 = 0.6
            } else if(oneDerection_mithril === "left") {
                x3 = -6
                y3 = -0.6
            }
            Player.getPlayer().field_70177_z += x3
            Player.getPlayer().field_70125_A += y3
            LeftClick.setState(false)
            waitLookingAway_mithril += 1
        } else if(waitLookingAway_mithril === 15) {
            if(oneDerection_mithril === "right") {
                oneDerection_mithril = "left"
            } else if(oneDerection_mithril === "left") {
                oneDerection_mithril = "right"
            }
            Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotDrill))
            mining_mithril = true
            waitLookingAway_mithril += 1
            startMiningStuck_mithril = 0

        }

        let plX = Player.getX()
        let plZ = Player.getZ()
        let X1 = (plX - (Player.getX() % 1)) + 0.5
        let Z1 = (plZ - (Player.getZ() % 1)) + 0.5
        if(mining_mithril === true) {
            lookAtPrisMarine()
            mining_mithril = false
        } else if(mining_mithril === false && closestBlock_mithril != undefined) {
            if(World.getBlockAt(closestBlock_mithril.getX(), closestBlock_mithril.getY(),closestBlock_mithril.getZ()).toString().includes("air")) {
                mining_mithril = true
            }
        }

        
    }
    if(Enabled_findlobby === true) {
    const PlayerCon = Player.getContainer()
    if(PlayerCon.getSize() === 90 || PlayerCon.getSize() === 63) {
        if(PlayerCon.getStackInSlot(16) != null) {
            if(PlayerCon.getStackInSlot(16).getID() === 328) {
            if(coolDownInOut_enterExit < 10) {
                coolDownInOut_enterExit += 1
            } else if(coolDownInOut_enterExit === 10) {
                PlayerCon.click(16,false,"MIDDLE")
                coolDownInOut_enterExit = 0
            }
        }
        } else if(PlayerCon.getStackInSlot(11) != null) {
            if(PlayerCon.getStackInSlot(11).getID() === 159) {
            if(coolDownInOut_Confirm < 10) {
                coolDownInOut_Confirm += 1
            } else if(coolDownInOut_Confirm === 10) {
                PlayerCon.click(11,false,"MIDDLE")
                coolDownInOut_enterExit
                coolDownWaitTime = 0
           }
        }
    }
    } else if(coolDownWaitTime < 50) {
        coolDownWaitTime += 1
    } else if(coolDownWaitTime === 50) {
        coolDownWaitTime += 1
        let worldTime = World.getTime()
        let found = false
        for(let g = 0; g < list.length; g++) {
            for(let f = 0; f < locations.length; f++) {
                if(list[g].toString().includes(locations[f])) {
                    ChatLib.chat(list[g])
                    found = true
                    break
                }
            }
        }
        if(worldTime < 96000 && found === true) {
            onStop_autoFind()
            ChatLib.chat(prefix + " Found good Lobby") 
        } else {
            let playerCurrentSlot = Player.getHeldItemIndex()
            Client.sendPacket(new C09PacketHeldItemChange(8));
            Client.sendPacket(new C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(8).getItemStack(), 0, 0, 0))
            Client.sendPacket(new C09PacketHeldItemChange(playerCurrentSlot));
        }
    }
}
if(((enabledOn_mithril === true) || (everythingON === true) || (on_Or_Off === true)) && settingNuker === 1) {
    if(Player.lookingAt().toString().includes(":cobblestone,")) {
        Client.sendPacket(new C09PacketHeldItemChange(hotBarSlotAotv));
    }
}
})

function onStart_autoFind() {
    ChatLib.chat(prefix + " Auto Lobby hop On")
    Enabled_findlobby = true
    toggleOnOff_findlobby = true
    let playerCurrentSlot = Player.getHeldItemIndex()
    Client.sendPacket(new C09PacketHeldItemChange(8));
    Client.sendPacket(new C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(8).getItemStack(), 0, 0, 0))
    Client.sendPacket(new C09PacketHeldItemChange(playerCurrentSlot));
}

function onStop_autoFind() {
    ChatLib.chat(prefix + " Auto Lobby hop Off")
    coolDownWaitTime = 1000
    Enabled_findlobby = false
    toggleOnOff_findlobby = false
}

let Enabled_findlobby = false
let toggleOnOff_findlobby = false
register("Command", () => {
    if(toggleOnOff_findlobby === false) { 
        onStart_autoFind()
    } else if(toggleOnOff_findlobby === true) {
        onStop_autoFind()
    }
}).setName("findlobby")

let list = Scoreboard.getLines()
let locations = ["Goblin", "Jungle", "Mithril", "Precursor", "Magma", "Crystal"]
function ScoreBoard() {
    let found = false
    for(let g = 0; g < list.length; g++) {
        for(let f = 0; f < locations.length; f++) {
            if(list[g].toString().includes(locations[f])) {
                ChatLib.chat(list[g])
                found = true
                break
            }
        }
        if(found === true) {
            break
        }
    }
    if(found === true) {
        return false
    } else {
        return true
    }
}

function onStart_nuker() {
    ChatLib.chat(prefix + " Enabled nuker")
    toggle_nuker = true
    enable_nuker = true
}

function onStop_nuker() {
    ChatLib.chat(prefix + " Disabled nuker")
    toggle_nuker = false
    enable_nuker = false
}

let kb_nuker = new KeyBind("Nuker", Keyboard.KEY_NONE, "BarryBunsClient")
let toggle_nuker = false
let enable_nuker = false
register("Step", () => {
    if (kb_nuker.isPressed()) {
        if(toggle_nuker === false) {
            onStart_nuker()
        } else if(toggle_nuker === true) {
            onStop_nuker()
        }
    }
})

let resetBlock_nuker = 0
register("Tick", () => {
    if(enable_nuker === true) {
        let amount = 0
        let lastClickedBlock = "null"
        while(amount < 2) {
            amount += 1
            let first = true
            let closestBlock = undefined
            let closestPos = undefined
            scanHardStone()
            for(let i = 0; i < blocks_Hardstone.length; i++) {
                if((first === true)) {
                    first = false
                    closestBlock = blocks_Hardstone[i]
                    closestPos = new net.minecraft.util.BlockPos(closestBlock.getX(), closestBlock.getY(), closestBlock.getZ())
                }
                else if((distanceToPlayer(blocks_Hardstone[i].getX(), blocks_Hardstone[i].getY(), blocks_Hardstone[i].getZ()) < distanceToPlayer(closestBlock.getX(), closestBlock.getY(), closestBlock.getZ()) && lastClickedBlock.toString() != blocks_HardstonePos[i].toString())) {
                    closestBlock = blocks_Hardstone[i]
                    closestPos = new net.minecraft.util.BlockPos(closestBlock.getX(), closestBlock.getY(), closestBlock.getZ())
                }
            }
            if(closestPos != undefined) {
                    //Client.sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, closestPos, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                    mc.field_71439_g.field_71174_a.func_147297_a(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, closestPos, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                    mc.field_71439_g.func_71038_i()
                    whiteListedBlocks.push(closestPos)
                    //ChatLib.chat("clicked: " + closestPos + "  " + amount)
                    // if(amount === 1) {
                    //     lastClickedBlock = closestPos
                    // }
                    if(resetBlock_nuker < 8) {
                        resetBlock_nuker += 1
                    } else if(resetBlock_nuker === 8) {
                        resetBlock_nuker = 0
                        whiteListedBlocks = []
                    }
            }
    }
}
})

let blocks_Hardstone = []
let blocks_HardstonePos = []
let blocksForNuker = [":stone,", "ore"]
let whiteListedBlocks = []
function scanHardStone() {
    blocks_Hardstone = []
    blocks_HardstonePos = []
    for (let x = 0; x < 8; x++) {
        for (let y = 0; y < 4; y++) {
            for (let z = 0; z < 8; z++) {
                let block = World.getBlockAt(Player.getX() + x - 4, Player.getY() + y, Player.getZ() + z - 4)
                let pos = new net.minecraft.util.BlockPos(block.getX(), block.getY(), block.getZ())
                for(let i = 0; i < blocksForNuker.length; i++) {
                    if(block.toString().includes(blocksForNuker[i]) && (distanceToPlayerHead(block.getX(),block.getY(),block.getZ()) < 4.5)) {
                        let foundWhiteList = false
                        for(let w = 0; w < whiteListedBlocks.length; w++) {
                            if(whiteListedBlocks[w].toString() === pos.toString()) {
                                foundWhiteList = true
                                break
                            }
                        }
                        if(foundWhiteList === false) {
                        blocks_HardstonePos.push(pos)
                        blocks_Hardstone.push(block)
                        }
                }
            }
        }
    }   
}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var mineX = [];
var mineY = [];
var mineZ = [];
var color = [0,0,1];
var routeToggle = false;
var routeIndex;
register('command', () => {

    routeToggle = !routeToggle;
    routeIndex = 0;

    if (routeToggle) {

        ChatLib.chat(prefix + "§aRoute Assist Toggled ON");

        selectedAotvCords();
        /*
        aotvBlocksX = [429, 426, 433, 433, 440, 447, 460, 462, 444, 446, 449, 454, 465, 462, 468, 462, 467, 464, 473, 478, 486, 474, 480, 486, 480, 486, 481, 475, 469, 462, 457, 462, 456, 456, 440, 442]
        aotvBlocksY = [45, 43, 47, 45, 44, 39, 30, 30, 31, 34, 34, 36, 39, 43, 31, 36, 41, 47, 31, 34, 39, 53, 43, 44, 51, 56, 56, 44, 54, 48, 47, 58, 58, 53, 39, 41]
        aotvBlocksZ = [589, 584, 585, 588, 583, 583, 575, 581, 600, 604, 624, 622, 618, 622, 625, 629, 631, 632, 644, 643, 644, 644, 633, 628, 627, 623, 616, 617, 622, 608, 610, 605, 596, 608, 611, 600]
        */
        /*
        aotvBlocksX = [451, 453, 456];
        aotvBlocksY = [ 149, 149, 149 ];
        aotvBlocksZ = [ 584, 582, 583 ];
        */
        //console.log(aotvBlocksX.length);
        aotvBlocksX.push(aotvBlocksX[0]);
        aotvBlocksY.push(aotvBlocksY[0]);
        aotvBlocksZ.push(aotvBlocksZ[0]);
        //console.log(aotvBlocksX.length);
        /*
        if (settingCurrentAotvCords === 0.0) {
            aotvBlocksX = [429, 426, 433, 433, 440, 447, 460, 462, 444, 446, 449, 454, 465, 462, 468, 462, 467, 464, 473, 478, 486, 474, 480, 486, 480, 486, 481, 475, 469, 462, 457, 462, 456, 456, 440, 442]
            aotvBlocksY = [45, 43, 47, 45, 44, 39, 30, 30, 31, 34, 34, 36, 39, 43, 31, 36, 41, 47, 31, 34, 39, 53, 43, 44, 51, 56, 56, 44, 54, 48, 47, 58, 58, 53, 39, 41]
            aotvBlocksZ = [589, 584, 585, 588, 583, 583, 575, 581, 600, 604, 624, 622, 618, 622, 625, 629, 631, 632, 644, 643, 644, 644, 633, 628, 627, 623, 616, 617, 622, 608, 610, 605, 596, 608, 611, 600]
            ChatLib.chat(aotvBlocksX.length)
        } else if (settingCurrentAotvCords === 1.0) {
            aotvBlocksX = [769, 772, 774, 776, 775, 778, 782, 791, 784, 779, 788, 796, 798, 797, 798, 779, 778, 789, 783, 786, 781, 780, 782]
            aotvBlocksY = [61, 60, 59, 59, 55, 61, 53, 54, 52, 55, 46, 44, 49, 50, 53, 30, 34, 32, 32, 32, 31, 34, 39]
            aotvBlocksZ = [672, 666, 661, 655, 651, 651, 656, 660, 664, 664, 667, 675, 682, 688, 693, 669, 666, 668, 664, 657, 655, 649, 649]
        } else if (settingCurrentAotvCords === 2.0) {
            aotvBlocksX = [466, 466, 463, 460, 463, 470, 472, 488, 476, 476, 490, 492, 485, 478, 478, 487, 488, 502, 494, 503, 500, 506, 503, 492, 492, 485, 488, 480, 475, 474]
            aotvBlocksY = [63, 65, 64, 69, 76, 79, 82, 69, 69, 65, 68, 78, 82, 68, 64, 69, 77, 91, 82, 64, 65, 68, 75, 66, 78, 83, 64, 69, 69, 75]
            aotvBlocksZ = [758, 773, 776, 783, 786, 788, 782, 788, 786, 794, 776, 790, 791, 774, 801, 803, 801, 795, 780, 786, 790, 778, 775, 768, 773, 773, 761, 759, 754, 759]
        } else if (settingCurrentAotvCords === 3.0) {
            ChatLib.chat(prefix + " " + aotvBlocksX.length + " Cords")
        }
        */
        makeArray()
    }
    else {
        ChatLib.chat(prefix + "§cRoute Assist Toggled OFF");
    }
}).setName("route");

register('renderWorld', () => {

    if (routeToggle) {
        //console.log(routeIndex + ", " + mineX.length);

        if (routeIndex < mineX.length) {

            var block = World.getBlockAt(mineX[routeIndex], mineY[routeIndex], mineZ[routeIndex]); //gets info about block at a coordinate

            //console.log(block.type);
            routeColor( routeIndex );

            RenderLib.drawInnerEspBox(mineX[routeIndex] + 0.5, mineY[routeIndex], mineZ[routeIndex] + 0.5, 1, 1, color[0], color[1], color[2], color[3], true); //1st block I need help, no idea why this crashes you.

            if (routeIndex + 1 < mineX.length) {

                var block1 = World.getBlockAt(mineX[routeIndex + 1], mineY[routeIndex + 1], mineZ[routeIndex + 1]);

                if (!(block1.type == "BlockType{name=minecraft:air}" || block1.type == "BlockType{name=minecraft:stained_glass_pane}" || block1.type == "BlockType{name=minecraft:stained_glass}" || block1.type == "BlockType{name=minecraft:cobblestone}" || block1.type == "BlockType{name=minecraft:chest}")) {

                    RenderLib.drawEspBox(mineX[routeIndex + 1] + 0.5, mineY[routeIndex + 1], mineZ[routeIndex + 1] + 0.5, 1, 1, 1, 5, 5, 1, true);

                }

                if (routeIndex + 2 < mineX.length) {

                    var block2 = World.getBlockAt(mineX[routeIndex + 2], mineY[routeIndex + 2], mineZ[routeIndex + 2]);

                    if (!(block2.type == "BlockType{name=minecraft:air}" || block2.type == "BlockType{name=minecraft:stained_glass_pane}" || block2.type == "BlockType{name=minecraft:stained_glass}" || block2.type == "BlockType{name=minecraft:cobblestone}" || block2.type == "BlockType{name=minecraft:chest}")) {

                        RenderLib.drawEspBox(mineX[routeIndex + 2] + 0.5, mineY[routeIndex + 2], mineZ[routeIndex + 2] + 0.5, 1, 1, 1, 1, 1, 1, true);
                    }
                }

            }
        }
        else {
            routeToggle = false;
            ChatLib.chat(prefix + "§cRoute Assist Toggled OFF");
        }

        if (routeIndex < mineX.length) {
            if ((block.type == "BlockType{name=minecraft:air}" || block.type == "BlockType{name=minecraft:stained_glass_pane}" || block.type == "BlockType{name=minecraft:stained_glass}" || block.type == "BlockType{name=minecraft:cobblestone}" || block.type == "BlockType{name=minecraft:chest}")) {
                routeIndex = routeIndex + 1;
            }
        }
    }

    /*
    if (Math.floor(Player.getX()) == 85 && Math.floor(Player.getZ()) == -98 && autoDisconnect == 1) {
        Client.disconnect();
    }
    */
})

register('command', () => {
    console.log(mineX[routeIndex] + ", " + mineY[routeIndex] + ", " + mineZ[routeIndex])
}).setName("show")

function routeColor( index ){
    for (var i = 0; i < aotvBlocksX.length; i++) {
        if (mineX[index] == aotvBlocksX[i] && mineY[index] == aotvBlocksY[i] + 1 && mineZ[index] == aotvBlocksZ[i]) {
            color[0] = 0;
            color[1] = 0;
            color[2] = 1;
            color[3] = 1;

            break;
        }
        else {
            color[0] = 1;
            color[1] = 0;
            color[2] = 0;
            color[3] = 1;
        }
    }
}

function makeArray() {

    mineX = [];
    mineY = [];
    mineZ = [];

    for (var i = 0; i < aotvBlocksX.length - 1; i++) {
        calcBlocks(aotvBlocksX[i], aotvBlocksY[i], aotvBlocksZ[i], aotvBlocksX[i + 1], aotvBlocksY[i + 1], aotvBlocksZ[i + 1]);
    }
    //addBaritoneCoords();

    /*
    for (var i = 0; i < mineX.length - 1; i++) {
        console.log(mineX[i] + ', ' + mineY[i] + ', ' + mineZ[i] + ', ' + mineX[i + 1] + ', ' + mineY[i + 1] + ', ' + mineZ[i + 1]);
    }
    */
}

function calcBlocks(x1, y1, z1, x2, y2, z2) {

    y1 = y1 + 1; //dumb 18 fucked up coordinates

    y2 = y2 + 1;

    mineX.push(Math.floor(x1));

    mineY.push(Math.floor(y1));

    mineZ.push(Math.floor(z1));

    mineX.push(Math.floor(x1));

    mineY.push(Math.floor(y1) + 1);

    mineZ.push(Math.floor(z1));

    mineX.push(Math.floor(x1));

    mineY.push(Math.floor(y1) + 2);

    mineZ.push(Math.floor(z1));


    x1 = x1 + 0.5;
    //y1 = y1 + 0.5;
    y1 = y1 + 2.62 - 3 / 32; //shifting apparently lowers eye level by 3/32 block, needs testing. **should be fixed need more tests
    z1 = z1 + 0.5;

    x2 = x2 + 0.5;
    y2 = y2 + 0.5; // either Y or Y + 0.5 depending on what 18's macro looks at. currently his macro looks at Y
    z2 = z2 + 0.5;

    var changeX = (x2 - x1) / 100; // if someone can find a better number based on math than this im all ears. I was just too lazy, 10k should be fine
    var changeY = (y2 - y1) / 100;
    var changeZ = (z2 - z1) / 100;
    var curX = x1;
    var curY = y1;
    var curZ = z1;
    var blockX = Math.floor(curX);
    var blockY = Math.floor(curY);
    var blockZ = Math.floor(curZ);

    for (var counter = 1; counter <= 100; counter++) {
        blockX = Math.floor(curX);
        blockY = Math.floor(curY);
        blockZ = Math.floor(curZ);
        curX += changeX;
        curY += changeY;
        curZ += changeZ;
        if (blockX != Math.floor(curX) || blockY != Math.floor(curY) || blockZ != Math.floor(curZ)) {
            //console.log(blockX + ', ' + blockY + ', ' + blockZ );

            mineX.push(blockX);

            mineY.push(blockY);

            mineZ.push(blockZ);

            if (blockX != Math.floor(curX - 0.1)) {
                mineX.push(blockX - 1);

                mineY.push(blockY);

                mineZ.push(blockZ);
            }

            if (blockX != Math.floor(curX + 0.1)) {
                mineX.push(blockX + 1);

                mineY.push(blockY);

                mineZ.push(blockZ);
            }


            if (blockY != Math.floor(curY - 0.1)) {
                mineX.push(blockX);

                mineY.push(blockY - 1);

                mineZ.push(blockZ);
            }

            if (blockY != Math.floor(curY + 0.1)) {
                mineX.push(blockX);

                mineY.push(blockY + 1);

                mineZ.push(blockZ);
            }

            if (blockZ != Math.floor(curZ - 0.1)) {
                mineX.push(blockX);

                mineY.push(blockY);

                mineZ.push(blockZ - 1);
            }

            if (blockZ != Math.floor(curZ + 0.1)) {
                mineX.push(blockX);

                mineY.push(blockY);

                mineZ.push(blockZ + 1);
            }

            //console.log(coordsJ.length);
        }

    }
}


///////////////////////////////////////////////////////
///////////////////////////////////////////////////////

register("Chat", (theMsg) => {
    if(theMsg.toString().includes("remaining on your pass")) {
        ChatLib.say("/purchasecrystallhollowspass")
    }
}).setCriteria("theMsg")
//auto renew pass

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
//auto compact sacks