import {
    @ButtonProperty,
    @CheckboxProperty,
    Color,
    @ColorProperty,
    @PercentSliderProperty,
    @SelectorProperty,
    @SwitchProperty,
    @TextProperty,
    @Vigilant,
} from 'Vigilance/index';

@Vigilant('barrybunsclient')
class Settings {
    @TextProperty({
        name: 'Stuck Time',
        description: 'Amount of ticks it waits until it says "Stuck While Mining" (Is in game Ticks, tick = 0.05 seconds)',
        category: 'General',
        placeholder: '60',
    })
    stuckTimer = '';

    @SelectorProperty({
        name: 'Smoothlook',
        description: 'Smoothlook in game Ticks (tick = 0.05 seconds)',
        category: 'General',
        options: ["1 Tick", "2 Ticks", "3 Ticks", "4 Ticks", "5 Ticks", "6 Ticks", "7 Ticks", "8 Ticks", "9 Ticks", "10 Ticks"],
    })
    smoothLook = 1;

    @SelectorProperty({
        name: 'Sneak',
        description: 'Sneaks while Macroing',
        category: 'General',
        options: ["On", "Off"],
    })
    currentSneak = 1;

    @SelectorProperty({
        name: 'Fake Look',
        description: 'You mine the block before allready looking at it (improves Money an hour) Doesnot work for Mithril for Now',
        category: 'General',
        options: ["On", "Off"],
    })
    currentNuke = 1;

@SelectorProperty({
    name: 'PresisionMiner Support',
    description: 'Will Look at the Paricles, !ONLY works if fake look is On',
    category: 'General',
    options: ["On", "Off"],
})
currentPresisionMiner = 1;

    @SelectorProperty({
        name: 'Big Blocks only',
        description: 'The macro will only mine the big block gemstones, not the small ones',
        category: 'General',
        options: ["On", "Off"],
    })
    currentBigBlocks = 1;

    @SelectorProperty({
        name: 'Player Detection',
        description: 'Will warp out when a player comes near you',
        category: 'General',
        options: ["On", "Off"],
    })
    playerDetection = 1; 

    @SelectorProperty({
        name: 'Macro Spot Gemstone',
        description: 'Says in What spot you Macro',
        category: 'General',
        options: ["Near Nucleus, Goblin Holdout (class j, Ruby)", "Edge of the Map, Precursor Remnants (class m, Ruby)", "Edge of the Map, Goblin Holdout (class d, Amber)", "Middle of the map Goblin Holdout (class c, Ruby)", "Custom cords", "No rendering"],
    })
    currentMacroSpot = 0;   

    @SelectorProperty({
        name: 'Macro Spot Mithril',
        description: 'Says in What spot you Macro',
        category: 'General',
        options: ["Goblin Holdout (class a)"],
    })
    currentMacroSpot_mithirl = 0; 


    @SelectorProperty({
        name: 'Auto Disconnect',
        description: 'Automatically disconnect from the server when kicked from a Crystal Hollows Lobby',
        category: 'General',
        options: ["On", "Off"],
    })
    autoDisconnect = 1;

    constructor() {
        this.initialize(this);
        //this.registerListener('textInput', newText => {
        //console.log(Text changed to ${newText});
        //});
        this.setCategoryDescription('General', 'All the Settings (very original GUI, I know)');
    }
}
export default new Settings;